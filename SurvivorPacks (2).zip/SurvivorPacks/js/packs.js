
// Rarity definitions with their colors and odds
import { gameState, saveGame } from '../script.js';

const RARITY_CONFIG = {
  common: { color: '#CCCCCC', pullRate: 0.60, name: 'Common', ep: 1 },
  rare: { color: '#1E90FF', pullRate: 0.25, name: 'Rare', ep: 3 },
  epic: { color: '#800080', pullRate: 0.10, name: 'Epic', ep: 6 },
  legendary: { color: '#FFA500', pullRate: 0.04, name: 'Legendary', ep: 12 },
  mythic: { color: '#FF1493', pullRate: 0.009, name: 'Mythic', ep: 24 },
  unique: { color: '#FFD700', pullRate: 0.001, name: 'Unique', ep: 48 }
};

const CATEGORY_ODDS = {
  item: 0.40,
  survivor: 0.35,
  location: 0.25
};

// Card Sets Configuration
const CARD_SETS = {
  classic: {
    name: "Classic Set",
    description: "The original survivor pack set",
    items: {
      common: ['Basic Med Kit', 'Scrap Metal', 'Canned Food', 'Water Bottle'],
      rare: ['Advanced Med Kit', 'Toolbox', 'Radio'],
      epic: ['Military Grade Med Kit', 'Generator'],
      legendary: ['Advanced Generator'],
      mythic: ['Experimental Tech'],
      unique: ['Mysterious Artifact']
    },
    survivors: {
      common: [
        { id: null, name: 'John Smith', occupation: 'Scout', str: 3, dex: 4, int: 3, health: 100 },
        { id: null, name: 'Sarah Chen', occupation: 'Scavenger', str: 3, dex: 5, int: 2, health: 100 },
        { id: null, name: 'Mike Rodriguez', occupation: 'Builder', str: 5, dex: 3, int: 2, health: 100 }
      ],
      rare: [
        { name: 'Emma Williams', occupation: 'Medic', str: 4, dex: 5, int: 6, health: 100 },
        { name: 'James Kumar', occupation: 'Engineer', str: 4, dex: 4, int: 7, health: 100 },
        { name: 'Lisa Park', occupation: 'Mechanic', str: 5, dex: 6, int: 4, health: 100 }
      ],
      epic: [
        { name: 'Marcus Johnson', occupation: 'Soldier', str: 8, dex: 7, int: 5, health: 100 },
        { name: 'Dr. Elena Costa', occupation: 'Scientist', str: 5, dex: 6, int: 9, health: 100 }
      ],
      legendary: [
        { name: 'Commander Hayes', occupation: 'Commander', str: 9, dex: 8, int: 8, health: 100 },
        { name: 'Dr. Alexander Wu', occupation: 'Doctor', str: 7, dex: 8, int: 10, health: 100 }
      ],
      mythic: [
        { name: 'Colonel Sarah Blake', occupation: 'Veteran', str: 10, dex: 10, int: 9, health: 100 }
      ],
      unique: []
    },
    locations: {
      common: [
        { 
          name: 'Abandoned House',
          requirements: { ep: 2, food: 2, water: 2 },
          rewards: { scraps: 10, materials: 5 }
        },
        {
          name: 'Small Camp',
          requirements: { ep: 2, food: 3, water: 2 },
          rewards: { food: 8, water: 8 }
        },
        {
          name: 'Warehouse',
          requirements: { ep: 3, food: 3, water: 3 },
          rewards: { materials: 15, scraps: 12 }
        }
      ],
      rare: [
        {
          name: 'Hospital',
          requirements: { ep: 4, food: 4, water: 4, meds: 2 },
          rewards: { meds: 20, materials: 10 }
        },
        {
          name: 'Police Station',
          requirements: { ep: 5, food: 5, water: 5 },
          rewards: { materials: 25, meds: 15 }
        }
      ],
      epic: [
        {
          name: 'Military Base',
          requirements: { ep: 8, food: 8, water: 8, meds: 3 },
          rewards: { materials: 40, scraps: 35, meds: 20 }
        },
        {
          name: 'Research Lab',
          requirements: { ep: 7, food: 7, water: 7, meds: 4 },
          rewards: { meds: 45, materials: 30 }
        }
      ],
      legendary: [
        {
          name: 'Bunker',
          requirements: { ep: 12, food: 10, water: 10, meds: 5 },
          rewards: { materials: 80, scraps: 70, meds: 50, food: 40, water: 40 }
        }
      ],
      mythic: [],
      unique: []
    }
  }
  // Additional card sets can be added here
};

function pullCard(setName = 'classic') {
  // Check for expansion sets first
  const allCardSets = { ...CARD_SETS, ...(window.CARD_SETS || {}) };
  const cardSet = allCardSets[setName];
  if (!cardSet) {
    throw new Error(`Card set "${setName}" not found`);
  }

  // Determine category
  const categoryRoll = Math.random();
  let category;
  if (categoryRoll < CATEGORY_ODDS.item) {
    category = 'items';
  } else if (categoryRoll < CATEGORY_ODDS.item + CATEGORY_ODDS.survivor) {
    category = 'survivors';
  } else {
    category = 'locations';
  }

  // Determine rarity
  const rarityRoll = Math.random();
  let cumulativeChance = 0;
  let rarity;
  
  for (const [r, config] of Object.entries(RARITY_CONFIG)) {
    cumulativeChance += config.pullRate;
    if (rarityRoll <= cumulativeChance) {
      rarity = r;
      break;
    }
  }

  // Get available cards of that rarity and category
  const availableCards = cardSet[category][rarity];
  if (!availableCards || availableCards.length === 0) {
    // Fallback to next rarity down if no cards available
    const rarities = Object.keys(RARITY_CONFIG);
    const currentIndex = rarities.indexOf(rarity);
    for (let i = currentIndex - 1; i >= 0; i--) {
      const fallbackRarity = rarities[i];
      if (cardSet[category][fallbackRarity]?.length > 0) {
        rarity = fallbackRarity;
        break;
      }
    }
  }

  // Pull random card from available cards
  const cardPool = cardSet[category][rarity];
  const card = cardPool[Math.floor(Math.random() * cardPool.length)];

  const resourceValues = {
    common: { value: 5, type: 'scraps' },
    rare: { value: 10, type: 'food' },
    epic: { value: 15, type: 'water' },
    legendary: { value: 25, type: 'meds' },
    mythic: { value: 40, type: 'materials' },
    unique: { value: 100, type: 'materials' }
  };

  const baseCard = {
    setName,
    rarity,
    category,
    color: RARITY_CONFIG[rarity].color
  };

  if (category === 'survivors') {
    return {
      ...baseCard,
      name: card.name,
      occupation: card.occupation,
      stats: {
        str: card.str,
        dex: card.dex,
        int: card.int,
        health: card.health,
        ep: RARITY_CONFIG[rarity].ep
      }
    };
  } else if (category === 'items') {
    return {
      ...baseCard,
      name: card,
      resourceValue: resourceValues[rarity].value,
      resourceType: resourceValues[rarity].type
    };
  } else {
    return {
      ...baseCard,
      name: card.name,
      requirements: card.requirements,
      rewards: card.rewards
    };
  }
}

function openPack(cardCount = 3, setName = 'classic') {
  if (gameState.resources.scraps < 10) {
    throw new Error('Not enough scraps to open pack');
  }
  
  gameState.resources.scraps -= 10;
  const cards = [];
  for (let i = 0; i < cardCount; i++) {
    const card = pullCard(setName);
    cards.push(card);
    gameState.collection.push(card);
  }
  saveGame();
  return cards;
}

export { openPack, RARITY_CONFIG, CATEGORY_ODDS, CARD_SETS };
